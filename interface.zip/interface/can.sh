#!/bin/sh

ip link set can0 up type can bitrate 125000